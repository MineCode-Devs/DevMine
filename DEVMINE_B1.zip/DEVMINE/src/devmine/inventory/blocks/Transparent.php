<?php



namespace devmine\inventory\blocks;


abstract class Transparent extends Block{

	public function isTransparent(){
		return true;
	}
}