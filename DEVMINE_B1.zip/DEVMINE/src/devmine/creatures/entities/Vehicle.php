<?php



namespace devmine\creatures\entities;


abstract class Vehicle extends Entity implements Rideable{

}