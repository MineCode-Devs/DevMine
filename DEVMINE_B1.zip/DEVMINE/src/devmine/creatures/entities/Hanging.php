<?php



namespace devmine\creatures\entities;


abstract class Hanging extends Entity implements Attachable{

}