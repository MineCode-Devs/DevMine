<?php



namespace devmine\creatures\entities;


interface Tameable{

}