<?php



namespace devmine\creatures\entities;

class InstantEffect extends Effect{

}