<?php



namespace devmine\creatures\entities;


interface Rideable{

}