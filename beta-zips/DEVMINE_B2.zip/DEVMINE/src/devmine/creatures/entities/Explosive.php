<?php



namespace devmine\creatures\entities;


interface Explosive{

	public function explode();
}