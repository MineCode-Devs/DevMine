<?php



namespace devmine\server\events;

interface Listener{

}