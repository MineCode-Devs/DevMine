<?php



namespace devmine\inventory\blocks;

class StonePressurePlate extends PressurePlate{
	protected $id = self::STONE_PRESSURE_PLATE;

	public function getName() : string{
		return "Stone Pressure Plate";
	}
}