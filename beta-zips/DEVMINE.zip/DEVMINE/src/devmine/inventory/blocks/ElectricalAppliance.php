<?php



namespace devmine\inventory\blocks;

interface ElectricalAppliance{

}