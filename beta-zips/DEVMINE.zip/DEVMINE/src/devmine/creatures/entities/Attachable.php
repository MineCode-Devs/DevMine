<?php



namespace devmine\creatures\entities;


interface Attachable{

}