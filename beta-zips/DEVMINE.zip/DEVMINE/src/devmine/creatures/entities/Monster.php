<?php



namespace devmine\creatures\entities;


abstract class Monster extends Creature{

}